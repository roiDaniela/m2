Java to Scala
=============

Online Java to Scala converter

http://javatoscala.com

[![Deploy](https://www.herokucdn.com/deploy/button.png)](https://heroku.com/deploy)

## Usage
- Clone the repo
- Install sbt
- `sbt run`

## Contributors

- [Luka Zakrajšek](https://github.com/bancek) ([Koofr](http://koofr.eu))
- [Martin Mauch](https://github.com/nightscape)

## Issues

This is just a wrapper around `scalagen` library. Bugs should be reported to [scalagen repo](https://github.com/timowest/scalagen). Library is not maintained at the moment but the most recent branch is [this pull request](https://github.com/timowest/scalagen/pull/84).
